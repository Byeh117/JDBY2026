package com.example.banking_transfer_api.controller;

import com.example.banking_transfer_api.dto.auth.AuthResponse;
import com.example.banking_transfer_api.dto.auth.LoginRequest;
import com.example.banking_transfer_api.dto.auth.RegisterRequest;
import com.example.banking_transfer_api.service.AuthService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthController {

    private final AuthService authService;

    @PostMapping("/register")
    @ResponseStatus(HttpStatus.CREATED)
    public AuthResponse register(@Valid @RequestBody RegisterRequest request) {
        return authService.register(request);
    }

    @PostMapping("/login")
    public AuthResponse login(@Valid @RequestBody LoginRequest request) {
        return authService.login(request);
    }
}
